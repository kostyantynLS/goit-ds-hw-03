import requests
from bs4 import BeautifulSoup

import json

def parse_names(targetURL):

    html_doc = requests.get(targetURL)
    if html_doc.status_code != 200:
        print('HTTP response code: %d' % html_doc.status_code)
        exit

    soup = BeautifulSoup(html_doc.content, 'html.parser')

# born date
# <span class="author-born-date">June 01, 1926</span>
    ress = soup.select('span[class=author-born-date]')
    born_date.append(ress[0].text)

# bord location
#<span class="author-born-location">in The United States</span>
    ress = soup.select('span[class=author-born-location]')
    born_location.append(ress[0].text)

# description
# <div class="author-description">
    ress = soup.select('div[class=author-description]')
    descriptions.append(ress[0].text)

def parse_urls(targetURL):

    html_doc = requests.get(targetURL)

def parse_data(targetURL = "http://quotes.toscrape.com"):
    
    print(f'going to parse data from {targetURL}\n')

# reading pages
    pageid = 1
    URLsuffix = ""
    while True:
        print(f'reading page {pageid}: ', end="")

        html_doc = requests.get(targetURL+URLsuffix)
        if html_doc.status_code != 200:
            print('HTTP response code: %d' % html_doc.status_code)
            exit

        soup = BeautifulSoup(html_doc.content, 'html.parser')

    # quotes
        ress = soup.select('div[class=quote] span[class=text]')
        for ressid in ress:
            quotes.append(ressid.text)
        print('quotes = %d,' % len(quotes), end="")

    # author name
        ress = soup.select('div[class=quote] small[class=author]')
        for ressid in ress:
            fullname.append(ressid.text)
        print('full names = %d,' % len(quotes), end="")

    # author name URL
        ress = soup.select('div[class=quote] a[href]')
        idx = 0
        #remove unwanted URLs
        while True:
            if idx == len(ress):
                break
            text = str(ress[idx])
            if text.find('href="/author') <0:
                ress.pop(idx)
            else:
                idx += 1
        for ressid in ress:
            text = str(ressid)
            text = text.replace('<a href="', '')
            text = text.replace('">(about)</a>', '')
            fullname_urls.append(text)
        print('name URLs = %d,' % len(fullname_urls), end="")

    # tags
        ress = soup.select('div[class=quote] meta[class=keywords]')
        for ressid in ress:
            text = str(ressid)
            text = text.replace('<meta class="keywords" content="', '')
            text = text.replace('" itemprop="keywords"/>', '')
            tags.append(text.split(','))
        print('tags = %d,' % len(tags))

    #check for next page
        ress = soup.select('ul[class=pager] li[class=next] a[href]')    
        if len(ress):
            print('next page exist')
            pageid +=1
            URLsuffix = f'/page/{pageid}/'
        else:
            break   

    #autors infos
    print('looking for authors infos')
    for i in range(len(fullname_urls)):
        divided = i/len(fullname_urls) *100
        print('passing %.2f %%\r' % divided, end="")
        parse_names(targetURL+fullname_urls[i])

    print('searching finished')

# ---------------------------------------
if __name__ == '__main__':

    MangoDBaseURL = \
        "mongodb+srv://kostikgorin:RROK2oSkyoQxiVZe@cluster0.efdbn8u.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"


    quotes = list()
    tags = list()
    fullname = list()
    fullname_urls = list()
    born_date = list()
    born_location = list()
    descriptions = list()

    parse_data(targetURL = "http://quotes.toscrape.com")

    print('authors.json ...',end="")
    authors = list()
    for i in range(len(fullname)):
        authors.append({"fullname" : fullname[i],
                        "born_date" : born_date[i],
                        "born_location": born_location[i],
                        "description" : descriptions[i]})

    with open("authors.json", "w", encoding="utf-8") as f:
        json.dump(authors, f)
    print('saved')

    print('quotes.json ...',end="")
    quotelist = list()
    for i in range(len(quotes)):
        quotelist.append({"tags" : tags[i],
                          "author": fullname[i],
                          "quote" : quotes[i]})
    with open("quotes.json", "w", encoding="utf-8") as f:
        json.dump(quotelist, f)
    print('saved')
        