import random
import faker
from pymongo.server_api import ServerApi
from pymongo import MongoClient


class MongoBase():
    def __init__(self, MongoURL : str):
        try:
            self.url = MongoURL
            client = MongoClient( MongoURL, server_api=ServerApi('1') )
            self.base = client.book
        except Exception:
            print('fatal error!')
            exit

    def addRecord(self, cat_info : dict):
        return self.base.cats.insert_one( cat_info )

    def addRecords(self, cat_infos : list):
        return self.base.cats.insert_many( cat_infos )

    def updateRecord(self, cat_name, value_id, value):
        return self.base.cats.update_one({"name": cat_name}, {"$set": {value_id : value}})

    def deleteRecord(self, cat_name):
        return self.base.cats.delete_one({"name": cat_name})

    def getCats(self) -> list:
        names = []
        cats = self.base.cats.find({})
        for cat in cats:
            names.append(cat["name"])
        return names
    
    def showCatInfo(self, cat_name) -> list:
        cat_info = self.base.cats.find_one({"name": cat_name})
        return cat_info

    def deleteRecords(self):
        names = self.getCats()
        for cat in names:
            self.deleteRecord(cat)

# main module
if __name__ == '__main__':

    my_base_url = \
        "mongodb+srv://kostikgorin:RROK2oSkyoQxiVZe@cluster0.efdbn8u.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

#init_1
    myCats = MongoBase(my_base_url)

    fakes = faker.Faker()

#cat features list
    feature_list1 = ["ходить в лоток", "не ходить в лоток"]
    feature_list2 = ["дає себе гладити", "не дає себе гладити"]
    feature_list3 = ["сірий", "білий", "чорний", "рижий"]

#cats list
    cats = list()
    for id in range(1,6):
        cat_name = fakes.name().split(' ')
        cat_age = random.randint(1, 10)
        cat_features =  [   
                            feature_list1[ random.randint(1, len(feature_list1)-1) ],
                            feature_list2[ random.randint(1, len(feature_list2)-1) ],
                            feature_list3[ random.randint(1, len(feature_list3)-1) ],  
                        ]
        cat_id = {"name" : cat_name[0], "age" : cat_age, "features" : cat_features}
        cats.append(cat_id)

#add single cat
    myCats.addRecord(cats[0])
    cats.pop(0)

#add many cats
    myCats.addRecords(cats)

#get list of all cats
    what_cats = myCats.getCats()
    print(what_cats)
#updating
    myCats.updateRecord(what_cats[0], "age", 4)
#removing
    myCats.deleteRecord(what_cats[1])

#print info
    print(f'information about cat with name "{what_cats[-1]}"')
    info = myCats.showCatInfo(what_cats[-1])
    print(f'name \t\t:{info["name"]}')
    print(f'age\t\t:{info["age"]}')
    print('features\t:', end="")
    fea = ", ".join(info["features"])
    print(fea)

#deleting cats    
    print('\ndeleting all cats =)')
    myCats.deleteRecords()
